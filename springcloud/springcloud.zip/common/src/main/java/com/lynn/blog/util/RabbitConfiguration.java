package com.lynn.blog.util;

//import org.springframework.amqp.core.Queue;
import org.springframework.boot.SpringBootConfiguration;
/**
 * 
 * @author Administrator
 *
 */
@SpringBootConfiguration
public class RabbitConfiguration {

//	@Bean //自动创建消息队列名
//	public Queue queue() {
//		return new Queue("someQueue");
//	}
}
