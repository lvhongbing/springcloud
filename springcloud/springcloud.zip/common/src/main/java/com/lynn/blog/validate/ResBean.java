package com.lynn.blog.validate;

import java.io.Serializable;

import org.springframework.stereotype.Component;
@Component
public class ResBean implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
}
