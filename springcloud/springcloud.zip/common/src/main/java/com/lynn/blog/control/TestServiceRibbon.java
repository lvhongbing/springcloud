package com.lynn.blog.control;

public interface TestServiceRibbon {

	String test();
}
